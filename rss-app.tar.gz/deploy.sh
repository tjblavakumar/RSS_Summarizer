#!/bin/bash

# RSS Summarizer Deployment Script
set -e

echo "=== RSS Summarizer Deployment ==="

# Check if terraform is installed
if ! command -v terraform &> /dev/null; then
    echo "Error: Terraform is not installed. Please install Terraform first."
    exit 1
fi

# Check if AWS CLI is configured
if ! aws sts get-caller-identity &> /dev/null; then
    echo "Error: AWS CLI is not configured. Please run 'aws configure' first."
    exit 1
fi

# Generate SSH key pair if it doesn't exist
if [ ! -f ~/.ssh/rss_summarizer_key ]; then
    echo "Generating SSH key pair..."
    ssh-keygen -t rsa -b 4096 -f ~/.ssh/rss_summarizer_key -N ""
fi

# Create terraform.tfvars
cd terraform
if [ ! -f terraform.tfvars ]; then
    echo "Creating terraform.tfvars..."
    cat > terraform.tfvars << EOF
aws_region    = "us-east-1"
project_name  = "rss-summarizer"
instance_type = "t3.small"
public_key    = "$(cat ~/.ssh/rss_summarizer_key.pub)"
EOF
fi

# Initialize and apply Terraform
echo "Initializing Terraform..."
terraform init

echo "Planning Terraform deployment..."
terraform plan

echo "Applying Terraform configuration..."
terraform apply -auto-approve

# Get the public IP
PUBLIC_IP=$(terraform output -raw public_ip)
echo "Instance deployed at: $PUBLIC_IP"

echo "=== Deployment Instructions ==="
echo "1. Wait 2-3 minutes for the instance to fully initialize"
echo "2. Copy your application files to the server:"
echo "   scp -i ~/.ssh/rss_summarizer_key -r ../* ec2-user@$PUBLIC_IP:/home/ec2-user/rss-app/"
echo "3. SSH into the server:"
echo "   ssh -i ~/.ssh/rss_summarizer_key ec2-user@$PUBLIC_IP"
echo "4. Build and run the Docker container:"
echo "   cd /home/ec2-user/rss-app"
echo "   sudo docker-compose up -d"
echo "5. Access your application at: http://$PUBLIC_IP"

echo "=== Deployment Complete ==="